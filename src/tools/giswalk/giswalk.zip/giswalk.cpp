#include <stdio.h>

#include "giswalk.h"
#include "gwApp.h"
#include "gwTier.h"
#include <math.h>
#include <iostream>
#include <string>
using namespace std;


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tiffio.h>
#ifndef _WIN32
#include <inttypes.h>
#include <sys/time.h>
#else
#include <sys/types.h>
#include <sys/timeb.h>

#endif

#ifdef _WIN32
#ifndef _WINSOCKAPI_
struct timeval {
   int tv_sec;
   int tv_usec;
};
#endif

int gettimeofday(struct timeval *tv, struct timezone *tz)
{
   struct __timeb64 currentTime;
   (void)tz;
#if _MSC_VER < 1400
   _ftime64(&currentTime);
#else
   _ftime64_s(&currentTime);
#endif
   tv->tv_sec = currentTime.time;
   tv->tv_usec = currentTime.millitm * 1000;

   return 0;
}
#endif


int main(int argc, char **argv)
{
   if(argc==2)
   {
      timeval currentTime;
      gettimeofday(&currentTime,NULL);
      double startTime = currentTime.tv_sec + (double)currentTime.tv_usec / 1000000.0;
      srand((int)startTime);
      gwApp *app = new gwApp(argv[1]);
      gettimeofday(&currentTime,NULL);
      double initTime = currentTime.tv_sec + (double)currentTime.tv_usec / 1000000.0;
      app->run();
      gettimeofday(&currentTime,NULL);
      double computeTime = currentTime.tv_sec + (double)currentTime.tv_usec / 1000000.0;
      app->writeSVG();
      app->writeShape();
      gettimeofday(&currentTime,NULL);
      double writeTime = currentTime.tv_sec + (double)currentTime.tv_usec / 1000000.0;
      fprintf(stderr,"init %lf\n compute %lf\n write %lf\n complete %lf\n",initTime-startTime,computeTime-initTime, writeTime-computeTime, writeTime -startTime);
      delete app;
   }
   else
   {
      
      fprintf(stderr,"GisWalk (c)2010 Uwe Woessner V1.3.6\n");
      fprintf(stderr,"usage: giswalk mapFile[.tif,.hdr,.txt]\n");
   }
}



void myWarn(const char* c, const char*c2, va_list list)
{
    (void)c;
    (void)c2;
    (void)list;
}
unsigned char *tifread (const char *url, int *w, int *h, int *nc)
{
static int firstTime = 1;
  TIFF* tif;
  if(firstTime)
 {
    firstTime = 0;
    TIFFSetWarningHandler(myWarn);
}

  /*tiffDoRGBA = 1;*/
#ifdef _WIN32
  tif = TIFFOpen(url, "r");
#else
  tif = TIFFOpen(url, "r");
#endif
  if (tif)
  {
      size_t npixels;
      size_t widthbytes;
      int i;
      uint32* raster;
      unsigned char* raster2;
      unsigned char* image;
      int samples;
      samples = 4;
      TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, w);
      TIFFGetField(tif, TIFFTAG_IMAGELENGTH, h);
      TIFFGetField(tif, TIFFTAG_SAMPLESPERPIXEL, &samples);
      npixels = *w * *h;
      raster = (uint32*) malloc(npixels * sizeof (uint32));
      if (raster != NULL)
      {
          if (TIFFReadRGBAImage(tif, *w, *h, raster, 0))
          { 
            *nc=4;
            if(samples<4) {
                /* ugly hack by Uwe for grey scale/b/w images */
                *nc=40;
            }
            
            raster2 = (unsigned char*) malloc(npixels * sizeof (uint32));
            image = (unsigned char *)raster;
            widthbytes = *w * sizeof(uint32);
            for(i=0;i< *h;i++)
            {
                memcpy(raster2+(npixels * sizeof(uint32))-((i+1)*widthbytes),image+(i*widthbytes),widthbytes);
            }
            free(raster);
            
/* We have to byteswap on SGI ! */
#ifdef BIG_ENDIAN
            {
               int i;
               uint32_t *iPtr = (uint32_t*) raster2;
               for(i = 0;i < npixels;i++,iPtr++)
                  *iPtr = ((*iPtr & 0x000000ff) << 24 ) |
                          ((*iPtr & 0x0000ff00) <<  8 ) |
                          ((*iPtr & 0x00ff0000) >>  8 ) |
                          ((*iPtr & 0xff000000) >> 24 );
            }
#endif            

	    /*TIFFClose(tif);*/
            return (unsigned char *)raster2;
          }
       } 
  }
  return NULL;
}
