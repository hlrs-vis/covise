#!/bin/sh
java -jar TuioSimulator.jar $@
